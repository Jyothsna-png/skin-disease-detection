import os
import streamlit as st
import tensorflow as tf
import numpy as np
from tensorflow.python.keras.models import load_model

# Diagnostic Step 1: Verify TensorFlow installation and version
try:
    st.write(f"TensorFlow version: {tf._version_}")
except AttributeError as e:
    st.error(f"Error accessing TensorFlow version: {e}")
    st.stop()

# Inject CSS for custom styling
st.markdown("""
    <style>
    .title {
        font-size: 50px;
        color: #4CAF50;
        text-align: center;
    }
    .subtitle {
        font-size: 20px;
        color: #555;
        text-align: center;
    }
    .uploaded-image {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width: 50%;
    }
    .result {
        font-size: 20px;
        color: #d9534f;
        text-align: center;
        font-weight: bold;
    }
    </style>
    """, unsafe_allow_html=True)

st.markdown('<h1 class="title">Skin Disease Detection CNN Model</h1>', unsafe_allow_html=True)
st.markdown('<p class="subtitle">Upload an image of skin to classify the type of skin condition</p>', unsafe_allow_html=True)

# List of skin condition names
skin_names = [
    'Atopic Dermatitis', 'Benign Keratosis', 'Eruptive Xanthoma', 'Normal Skin',
    'Actinic Keratosis', 'Squamous Cell Carcinoma', 'Vascular Lesion', 'Dermatofibroma'
]

# Diagnostic Step 2: Load the pre-trained model
model_path = 'C:/miniswaroop/Split_smol/Skin_Recogz_Model_v2.h5'
try:
    model = load_model(model_path)
    st.write("Model loaded successfully.")
except Exception as e:
    st.error(f"Error loading model: {e}")
    st.stop()

# Function to classify images
def classify_images(image_path):
    try:
        input_image = tf.keras.utils.load_img(image_path, target_size=(180, 180))
        input_image_array = tf.keras.utils.img_to_array(input_image)
        input_image_exp_dim = np.expand_dims(input_image_array, axis=0)
        predictions = model.predict(input_image_exp_dim)
        result = tf.nn.softmax(predictions[0])
        outcome = f"The image belongs to {skin_names[np.argmax(result)]} with a score of {np.max(result) * 100:.2f}%"
        return outcome
    except Exception as e:
        return f"Error in classifying image: {e}"

# Streamlit file uploader
uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    # Save the uploaded file to a temporary location
    with open("temp.jpg", "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    st.image("temp.jpg", caption='Uploaded Image.', use_column_width=True, output_format='JPEG')
    st.write("")
    st.write("Classifying...")

    # Classify the image
    result = classify_images("temp.jpg")
    st.markdown(f'<p class="result">{result}</p>', unsafe_allow_html=True)