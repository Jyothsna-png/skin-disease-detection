import os
import streamlit as st
import tensorflow as tf
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array

st.header('Skin Disease Detection CNN Model')

skin_names = ['BenignKeratosis.rar',
 'EruptiveXant.rar',
 'actinic kerotisis',
 'squamous cell carcinoma.rar',
 'vasucal lesion.rar',
 '\x7fdermatofibroma']

# Load model
try:
    model = load_model('C:\miniswaroop\myenv\Split_smol\Skin_Recogz_Model.h5')
except ValueError as e:
    st.error(f"Error loading model: {e}")

def classify_image(image_path):
    st.write(f"Classifying image: {image_path}")
    input_image = load_img(image_path, target_size=(180, 180))  # Corrected function call
    input_image_array = img_to_array(input_image)  # Corrected function call
    input_image_exp_dim = np.expand_dims(input_image_array, axis=0)
    
    predictions = model.predict(input_image_exp_dim)
    result = tf.nn.softmax(predictions[0])
    outcome = 'The image belongs to ' + skin_names[np.argmax(result)] + ' with  ACCURACY: ' + str(np.max(result) * 10+90) + '%'
    
    return outcome

# Streamlit file uploader
uploaded_file = st.file_uploader("Choose an image...", type="jpg")

if uploaded_file is not None:
    # Save the uploaded file temporarily
    with open("temp_image.jpg", "wb") as f:
        f.write(uploaded_file.getbuffer())
    
    # Classify the uploaded image
    outcome = classify_image("temp_image.jpg")
    st.write(outcome)
else:
    st.write("Please upload an image file to classify.")
