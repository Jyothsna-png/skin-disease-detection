import os
import streamlit as st
import tensorflow as tf
import numpy as np
from tensorflow.keras.models import load_model as keras_load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array

# Ensure to install python-docx library for handling docx files
from docx import Document  

st.header('Skin Disease Detection CNN Model')

# Mapping disease names to their doc file paths
doc_files = {'ACANTHOSIS NIGRICANS':'C:\miniswaroop\myenv\document\Acanthosis Nigricans.docx',
 'ACTINIC KEROTOSIS':'C:\miniswaroop\myenv\document\Actinic Keratosis.docx',
 'ATOPIC DERMATITIS':'C:\miniswaroop\myenv\document\ATOPIC DERMATITIS.docx',
 'BENIGN KEROTOSIS':'C:\miniswaroop\myenv\document\Benign Keratosis.docx',
 'MILIARIA':'C:\miniswaroop\myenv\document\MILARIA.docx',
 'TINEA COROPORIS':'C:\miniswaroop\myenv\document\TINEA CORPORIS.docx',
 'VITILIGO':'C:\miniswaroop\myenv\document\Vitiligo.docx'
 } 

@st.cache_resource
def load_my_model():
    model = keras_load_model('c:\\miniswaroop\\myenv\\Split_smol\\Skin_Recogz_Model.h5')
    return model

model = load_my_model()

def classify_image(image_path):
    st.write(f"Classifying image: {image_path}")
    input_image = load_img(image_path, target_size=(180, 180))
    input_image_array = img_to_array(input_image)
    input_image_exp_dim = np.expand_dims(input_image_array, axis=0)
    
    predictions = model.predict(input_image_exp_dim)
    result = tf.nn.softmax(predictions[0])
    
    class_idx = np.argmax(result)
    class_name = list(doc_files.keys())[class_idx]
    st.write(f"Detected disease: **{class_name}**")
    
    # Attach the corresponding doc file
    doc_path = doc_files[class_name]
    with open(doc_path, "rb") as file:
        btn = st.download_button(
            label="Download Info Doc",
            data=file,
            file_name=f"{class_name}.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )
    
    return result

# Ensure the temporary directory exists
if not os.path.exists("temp"):
    os.makedirs("temp")

# Streamlit interface for uploading an image
uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])
if uploaded_file is not None:
    # Save the uploaded file to a temporary location
    image_path = f"temp/{uploaded_file.name}"
    with open(image_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    st.image(image_path, caption='Uploaded Image', use_column_width=True)
    
    # Classify the uploaded image
    result = classify_image(image_path)